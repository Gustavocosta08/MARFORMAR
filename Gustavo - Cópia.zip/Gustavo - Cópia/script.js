document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll("input[name='slider']");
    const prev = document.getElementById("prev");
    const next = document.getElementById("next");
    const botao = document.querySelector('.botao-menu');
    const menuLateral = document.querySelector('.menu-lateral');
    const conteudo = document.querySelector('.conteudo');
    const background = document.querySelector('.background');
    const slider = document.getElementById('slider');
    const inner = document.querySelector('.inner');
    const slidesContainer = document.querySelector('#slides');
    const numElements = document.querySelectorAll('.num');
    const nextSlide = document.querySelector('.next_slide');
    const prevSlide = document.querySelector('.prev_slide');

    let currentIndex = 0;

    const updateSlide = (index) => {
        currentIndex = index;
        slides[currentIndex].checked = true;
    };

    if (prev) {
        prev.addEventListener("click", () => {
            currentIndex = (currentIndex === 0) ? slides.length - 1 : currentIndex - 1;
            updateSlide(currentIndex);
        });
    }

    if (next) {
        next.addEventListener("click", () => {
            currentIndex = (currentIndex === slides.length - 1) ? 0 : currentIndex + 1;
            updateSlide(currentIndex);
        });
    }

    const alterarEstiloSard = (isMenuAtivo) => {
        document.querySelectorAll('.sard').forEach(sard => {
            sard.style.backgroundColor = isMenuAtivo ? 'rgba(0, 0, 0, 0.4)' : '#ffffff';
        });
    };

    const countUp = (element, start, end, duration) => {
        let startTimestamp = null;

        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            element.innerText = Math.floor(progress * (end - start) + start);

            if (progress < 1) {
                window.requestAnimationFrame(step);
            } else {
                element.innerText = end; 
            }
        };

        window.requestAnimationFrame(step);
    };

    const startCountUp = (element) => {
        const end = parseInt(element.getAttribute('data-target'), 10);
        countUp(element, 0, end, 2000);
    };

    const observeElementVisibility = () => {
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    startCountUp(entry.target);
                    observer.unobserve(entry.target); 
                }
            });
        }, { threshold: 0.5 });

        numElements.forEach(element => observer.observe(element));
    };

    const toggleMenu = () => {
        const isMenuAtivo = !menuLateral.classList.contains('ativo');
        menuLateral.classList.toggle('ativo');
        botao.classList.toggle('ativo');
        conteudo.classList.toggle('ativo');
        background.classList.toggle('ativo');
        slider.classList.toggle('slide-escuro');
        inner.classList.toggle('inner-escuro');
        slidesContainer.classList.toggle('overflow-escuro');
        document.body.style.backgroundColor = isMenuAtivo ? '#34495e' : '#ecf0f1';

        alterarEstiloSard(isMenuAtivo);
    };

    const closeMenu = () => {
        menuLateral.classList.remove('ativo');
        botao.classList.remove('ativo');
        conteudo.classList.remove('ativo');
        background.classList.remove('ativo');
        slider.classList.remove('slide-escuro');
        inner.classList.remove('inner-escuro');
        slidesContainer.classList.remove('overflow-escuro');
        document.body.style.backgroundColor = '#ecf0f1';

        alterarEstiloSard(false);
    };

    if (botao) botao.addEventListener('click', toggleMenu);

    if (background) background.addEventListener('click', closeMenu);

    observeElementVisibility();

    if (nextSlide) {
        nextSlide.addEventListener('click', () => {
            let items = document.querySelectorAll('.item');
            document.querySelector('.slide').appendChild(items[0]);
        });
    }

    if (prevSlide) {
        prevSlide.addEventListener('click', () => {
            let items = document.querySelectorAll('.item');
            document.querySelector('.slide').prepend(items[items.length - 1]);
        });
    }
});
